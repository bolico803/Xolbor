import express from 'express';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const postsPath = join(__dirname, '../data/posts.json');
const usersPath = join(__dirname, '../data/users.json');

import multer from 'multer';
import path from 'path';

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'server/uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, 'avatar-' + Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

const router = express.Router();

function getPosts() {
    const data = fs.readFileSync(postsPath, 'utf8');
    return JSON.parse(data);
}

function getUsers() {
    const data = fs.readFileSync(usersPath, 'utf8');
    return JSON.parse(data);
}

router.get('/:username', (req, res) => {
    const username = req.params.username;
    const users = getUsers();
    const user = users.find(u => u.username === username);

    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    const posts = getPosts().filter(p => p.user === username);
    res.json({
        username: user.username,
        bio: user.bio || 'Passionné par Instatock',
        avatar: user.avatar || '👤',
        posts: posts
    });
});

router.post('/avatar', upload.single('avatar'), (req, res) => {
    const { username } = req.body;
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

    const users = getUsers();
    const user = users.find(u => u.username === username);

    if (user) {
        const avatarPath = `/uploads/${req.file.filename}`;
        user.avatar = avatarPath;

        // Save updated users list
        fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));

        res.json({ avatar: avatarPath });
    } else {
        res.status(404).json({ error: 'User not found' });
    }
});

export default router;
