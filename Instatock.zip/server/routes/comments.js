import express from 'express';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const commentsPath = join(__dirname, '../data/comments.json');
const postsPath = join(__dirname, '../data/posts.json');

import { createNotification } from '../utils/notify.js';

const router = express.Router();

function getComments() {
    const data = fs.readFileSync(commentsPath, 'utf8');
    return JSON.parse(data);
}

function saveComments(comments) {
    fs.writeFileSync(commentsPath, JSON.stringify(comments, null, 2));
}

router.get('/:postId', (req, res) => {
    const comments = getComments();
    const postComments = comments.filter(c => c.postId === parseInt(req.params.postId));
    res.json(postComments);
});

router.post('/', (req, res) => {
    const { postId, user, text } = req.body;
    const comments = getComments();
    const newComment = {
        id: Date.now(),
        postId,
        user,
        text,
        date: new Date().toISOString()
    };
    comments.push(newComment);
    saveComments(comments);

    // Notify post owner
    const posts = JSON.parse(fs.readFileSync(postsPath, 'utf8'));
    const post = posts.find(p => p.id === postId);
    if (post) {
        createNotification(user, post.user, 'comment', postId, text);
    }

    res.status(201).json(newComment);
});

export default router;
