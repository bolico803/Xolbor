import express from 'express';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const notificationsPath = join(__dirname, '../data/notifications.json');

const router = express.Router();

function getNotifications() {
    return JSON.parse(fs.readFileSync(notificationsPath, 'utf8'));
}

function saveNotifications(notifications) {
    fs.writeFileSync(notificationsPath, JSON.stringify(notifications, null, 2));
}

router.get('/:username', (req, res) => {
    const username = req.params.username;
    const notifications = getNotifications();
    const userNotifications = notifications.filter(n => n.targetUser === username);
    res.json(userNotifications.reverse()); // Latest first
});

// Helper to add notification (not a public route, used internally or via specific endpoint)
router.post('/add', (req, res) => {
    const { fromUser, targetUser, type, postId, text } = req.body;
    if (fromUser === targetUser) return res.json({ status: 'skipped' });

    const notifications = getNotifications();
    notifications.push({
        id: Date.now(),
        fromUser,
        targetUser,
        type, // 'like', 'comment', 'follow'
        postId,
        text,
        date: new Date().toISOString(),
        read: false
    });
    saveNotifications(notifications);
    res.json({ status: 'success' });
});

export default router;
