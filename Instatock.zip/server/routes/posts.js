import express from 'express';
const router = express.Router();

import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const postsPath = join(__dirname, '../data/posts.json');

import { createNotification } from '../utils/notify.js';

import multer from 'multer';
import path from 'path';

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'server/uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

function getPosts() {
    const data = fs.readFileSync(postsPath, 'utf8');
    return JSON.parse(data);
}

function savePosts(posts) {
    fs.writeFileSync(postsPath, JSON.stringify(posts, null, 2));
}

router.get('/', (req, res) => {
    res.json(getPosts());
});

router.post('/', upload.single('file'), (req, res) => {
    const { user, caption, type, tags } = req.body;
    const posts = getPosts();

    const newPost = {
        id: Date.now(),
        user: user || 'Anonyme',
        likes: 0,
        caption,
        type: type || 'image',
        url: req.file ? `/uploads/${req.file.filename}` : 'https://picsum.photos/800/800',
        tags: tags ? JSON.parse(tags) : []
    };
    posts.unshift(newPost);
    savePosts(posts);

    // Notify tagged users
    if (newPost.tags && newPost.tags.length > 0) {
        newPost.tags.forEach(tag => {
            const taggedUser = tag.replace('@', '').trim();
            if (taggedUser && taggedUser !== newPost.user) {
                createNotification(newPost.user, taggedUser, 'tag', newPost.id, 'vous a identifié dans une publication.');
            }
        });
    }

    res.status(201).json(newPost);
});

router.post('/:id/like', (req, res) => {
    const { fromUser } = req.body;
    const posts = getPosts();
    const post = posts.find(p => p.id === parseInt(req.params.id));
    if (post) {
        post.likes++;
        savePosts(posts);
        if (fromUser) createNotification(fromUser, post.user, 'like', post.id);
        res.json(post);
    } else {
        res.status(404).json({ error: 'Post not found' });
    }
});

router.delete('/:id', (req, res) => {
    const id = parseInt(req.params.id);
    let posts = getPosts();
    const post = posts.find(p => p.id === id);

    if (!post) {
        return res.status(404).json({ error: 'Post not found' });
    }

    // Remove file if it's a local upload
    if (post.url.startsWith('/uploads/')) {
        const filePath = join(__dirname, '../../', post.url);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    }

    posts = posts.filter(p => p.id !== id);
    savePosts(posts);
    res.json({ message: 'Post deleted successfully' });
});

export default router;
