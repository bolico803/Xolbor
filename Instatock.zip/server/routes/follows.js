import express from 'express';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const followsPath = join(__dirname, '../data/follows.json');

import { createNotification } from '../utils/notify.js';

const router = express.Router();

function getFollows() {
    return JSON.parse(fs.readFileSync(followsPath, 'utf8'));
}

function saveFollows(follows) {
    fs.writeFileSync(followsPath, JSON.stringify(follows, null, 2));
}

router.post('/toggle', (req, res) => {
    const { follower, following } = req.body;
    let follows = getFollows();

    const index = follows.findIndex(f => f.follower === follower && f.following === following);

    if (index > -1) {
        follows.splice(index, 1);
        res.json({ status: 'unfollowed' });
    } else {
        follows.push({ follower, following });
        createNotification(follower, following, 'follow');
        res.json({ status: 'followed' });
    }
    saveFollows(follows);
});

router.get('/stats/:username', (req, res) => {
    const username = req.params.username;
    const follows = getFollows();

    const followers = follows.filter(f => f.following === username).map(f => f.follower);
    const following = follows.filter(f => f.follower === username).map(f => f.following);

    res.json({ followers, following });
});

export default router;
