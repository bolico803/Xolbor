import express from 'express';
const router = express.Router();

// Mock Data
let channels = [];

router.get('/', (req, res) => {
    res.json(channels);
});

router.post('/', (req, res) => {
    const { name, icon } = req.body;
    const newChannel = {
        id: channels.length + 1,
        name,
        members: 1,
        icon: icon || '📺'
    };
    channels.push(newChannel);
    res.status(201).json(newChannel);
});

export default router;
