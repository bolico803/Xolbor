import express from 'express';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const usersPath = join(__dirname, '../data/users.json');

const router = express.Router();

function getUsers() {
    const data = fs.readFileSync(usersPath, 'utf8');
    return JSON.parse(data);
}

function saveUsers(users) {
    fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));
}

router.post('/signup', (req, res) => {
    const { username, password } = req.body;
    const users = getUsers();

    if (users.find(u => u.username === username)) {
        return res.status(400).json({ error: 'Utilisateur existe déjà' });
    }

    const newUser = { username, password }; // In real app, hash password!
    users.push(newUser);
    saveUsers(users);

    res.status(201).json({ message: 'Compte créé avec succès', user: username });
});

router.post('/login', (req, res) => {
    const { username, password } = req.body;
    const users = getUsers();

    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        res.json({ message: 'Connexion réussie', user: username });
    } else {
        res.status(401).json({ error: 'Identifiants invalides' });
    }
});

export default router;
