import express from 'express';
import cors from 'cors';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

import postsRouter from './routes/posts.js';
import channelsRouter from './routes/channels.js';
import authRouter from './routes/auth.js';
import commentsRouter from './routes/comments.js';

import profilesRouter from './routes/profiles.js';
import followsRouter from './routes/follows.js';
import notificationsRouter from './routes/notifications.js';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Serving uploads staticly
app.use('/uploads', express.static(join(__dirname, 'uploads')));

// API Routes
app.use('/api/auth', authRouter);
app.use('/api/posts', postsRouter);
app.use('/api/channels', channelsRouter);
app.use('/api/comments', commentsRouter);
app.use('/api/profiles', profilesRouter);
app.use('/api/follows', followsRouter);
app.use('/api/notifications', notificationsRouter);

// Serving static files from the build directory (vite)
app.use(express.static(join(__dirname, '../'))); // Serving from root for dev simplicity

app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'Instatock API is running' });
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
