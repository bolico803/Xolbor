import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const notificationsPath = join(__dirname, '../data/notifications.json');

export function createNotification(fromUser, targetUser, type, postId = null, text = null) {
    if (fromUser === targetUser) return;

    const notifications = JSON.parse(fs.readFileSync(notificationsPath, 'utf8'));
    notifications.push({
        id: Date.now(),
        fromUser,
        targetUser,
        type,
        postId,
        text,
        date: new Date().toISOString(),
        read: false
    });
    fs.writeFileSync(notificationsPath, JSON.stringify(notifications, null, 2));
}
