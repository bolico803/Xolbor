const appState = {
  view: 'login',
  posts: [],
  channels: [],
  user: null
};

localStorage.removeItem('user');

if (!appState.user) {
  appState.view = 'login';
} else {
  appState.view = 'feed';
}

async function fetchData(endpoint) {
  try {
    const response = await fetch(`/api/${endpoint}`);
    return await response.json();
  } catch (err) {
    console.error(`Error fetching ${endpoint}:`, err);
    return [];
  }
}

function checkSession() {
  const header = document.querySelector('header');
  const footer = document.querySelector('mobile-nav');
  const app = document.getElementById('app');

  // Update footer class reference if needed
  const mobileNav = document.querySelector('.mobile-nav');

  if (!appState.user) {
    if (header) header.style.display = 'none';
    if (mobileNav) mobileNav.style.display = 'none';
  } else {
    if (header) header.style.display = 'flex';
    if (mobileNav) mobileNav.style.display = 'flex';
  }
}

async function renderFeed() {
  const main = document.getElementById('main-content');
  main.innerHTML = '<div style="padding: 50px; text-align: center;"><span style="font-size: 40px; animation: spin 1s infinite linear;">⌛</span></div>';

  appState.posts = await fetchData('posts');

  if (appState.posts.length === 0) {
    main.innerHTML = '<div style="padding: 100px 20px; text-align: center; color: var(--text-secondary);">Aucun post pour le moment. Soyez le premier !</div>';
    return;
  }

  const postsHtml = await Promise.all(appState.posts.map(async post => {
    const comments = await fetchData(`comments/${post.id}`);
    const userData = await fetchData(`profiles/${post.user}`);
    const mediaHtml = post.type === 'video'
      ? `<video src="${post.url}" loop muted autoplay style="width: 100%; height: 100%; object-fit: contain;"></video>`
      : `<img src="${post.url}" style="width: 100%; display: block;">`;

    const avatarHtml = userData.avatar && userData.avatar.startsWith('/uploads')
      ? `<img src="${userData.avatar}" style="width: 100%; height: 100%; object-fit: cover;">`
      : `<div class="avatar-inner">${userData.avatar || '👤'}</div>`;

    return `
      <article class="post">
        <div class="post-header">
          <div class="avatar">${avatarHtml}</div>
          <span class="username" data-user="${post.user}">${post.user}</span>
        </div>
        <div class="post-media">
          ${mediaHtml}
        </div>
        <div class="post-actions">
          <button class="action-btn like-btn" data-id="${post.id}">❤️</button>
          <button class="action-btn comment-toggle" data-id="${post.id}">💬</button>
          <button class="action-btn">✈️</button>
          ${post.user === appState.user ? `<button class="action-btn delete-btn" data-id="${post.id}">🗑️</button>` : ''}
        </div>
        <div class="post-info">
          <p class="likes-count">${post.likes} Jaime</p>
          <p class="caption"><strong>${post.user}</strong> ${post.caption}</p>
          ${post.tags && post.tags.length > 0 && post.tags[0] !== '' ? `
            <div style="margin-top: 5px; font-size: 13px; color: var(--accent-color);">
              ${post.tags.map(tag => `<span style="cursor: pointer; margin-right: 5px;" class="tag-link">${tag.startsWith('@') ? tag : '@' + tag}</span>`).join(' ')}
            </div>
          ` : ''}
          
          <div class="comments-trigger" data-id="${post.id}">
            Voir les ${comments.length} commentaires
          </div>

          <div class="comments-section" id="comments-${post.id}" style="display: none; margin-top: 15px;">
            <div class="comments-list" style="margin-bottom: 12px; max-height: 200px; overflow-y: auto;">
              ${comments.map(c => `
                <div style="font-size: 13.5px; margin-bottom: 8px;">
                  <strong>${c.user}</strong> ${c.text}
                </div>
              `).join('')}
            </div>
            <div class="comment-input-container">
              <input type="text" placeholder="Ajouter un commentaire..." class="comment-field" data-id="${post.id}">
              <button class="comment-submit send-comment" data-id="${post.id}">Publier</button>
            </div>
          </div>
        </div>
      </article>
    `;
  }));

  main.innerHTML = postsHtml.join('');
  setupFeedInteractions();
}

function setupFeedInteractions() {
  document.querySelectorAll('.username').forEach(u => {
    u.onclick = () => renderProfile(u.getAttribute('data-user'));
    u.style.cursor = 'pointer';
  });

  document.querySelectorAll('.tag-link').forEach(tag => {
    tag.onclick = (e) => {
      const username = e.target.innerText.replace('@', '').trim();
      renderProfile(username);
    };
  });

  document.querySelectorAll('.like-btn').forEach(btn => {
    btn.onclick = async () => {
      const id = btn.getAttribute('data-id');
      btn.classList.add('liked');
      await fetch(`/api/posts/${id}/like`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fromUser: appState.user })
      });
      // Minor optimization: just increment displayed likes instead of full reload
      const likesEl = btn.closest('.post').querySelector('.likes-count');
      const count = parseInt(likesEl.innerText);
      likesEl.innerText = `${count + 1} Jaime`;
    };
  });

  document.querySelectorAll('.comment-toggle, .comments-trigger').forEach(btn => {
    btn.onclick = () => {
      const id = btn.getAttribute('data-id');
      const section = document.getElementById(`comments-${id}`);
      section.style.display = section.style.display === 'none' ? 'block' : 'none';
    };
  });

  document.querySelectorAll('.send-comment').forEach(btn => {
    btn.onclick = async () => {
      const id = parseInt(btn.getAttribute('data-id'));
      const input = document.querySelector(`.comment-input[data-id="${id}"]`) || document.querySelector(`.comment-field[data-id="${id}"]`);
      const text = input.value;
      if (!text) return;

      await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ postId: id, user: appState.user, text })
      });
      renderFeed(); // Re-render to show new comment
    };
  });

  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.onclick = async () => {
      if (!confirm('Voulez-vous vraiment supprimer ce post ?')) return;
      const id = btn.getAttribute('data-id');
      const res = await fetch(`/api/posts/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        renderFeed();
      } else {
        alert('Erreur lors de la suppression');
      }
    };
  });
}

async function renderProfile(username = appState.user) {
  const main = document.getElementById('main-content');
  main.innerHTML = '<div style="padding: 50px; text-align: center;">⌛</div>';
  const data = await fetchData(`profiles/${username}`);
  const followStats = await fetchData(`follows/stats/${username}`);
  const myFollows = await fetchData(`follows/stats/${appState.user}`);
  const isFollowing = followStats.followers.includes(appState.user);

  if (!data.username) {
    main.innerHTML = '<div style="padding: 100px 20px; text-align: center;">Utilisateur non trouvé.</div>';
    return;
  }

  main.innerHTML = `
    <div style="padding-bottom: 40px;">
      <div class="profile-header">
        <div class="profile-avatar" id="avatar-container" style="position: relative; cursor: ${data.username === appState.user ? 'pointer' : 'default'} ; overflow: hidden;">
          ${data.avatar.startsWith('/uploads') ? `<img src="${data.avatar}" style="width: 100%; height: 100%; object-fit: cover;">` : data.avatar}
          ${data.username === appState.user ? `<div style="position: absolute; bottom: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; opacity: 0; transition: opacity 0.2s;" id="avatar-overlay">📷</div>` : ''}
          <input type="file" id="avatar-input" style="display: none;" accept="image/*">
        </div>
        <div class="profile-info">
          <h2>${data.username}</h2>
          <div class="profile-stats">
            <div class="stat-item"><span class="stat-value">${data.posts.length}</span><span class="stat-label">posts</span></div>
            <div class="stat-item"><span class="stat-value">${followStats.followers.length}</span><span class="stat-label">followers</span></div>
            <div class="stat-item"><span class="stat-value">${followStats.following.length}</span><span class="stat-label">following</span></div>
          </div>
          <p style="font-size: 14px; color: var(--text-primary); margin-top: 10px;">${data.bio || 'Bienvenue sur mon profil !'}</p>
        </div>
      </div>
      
      <div style="padding: 0 20px 20px 20px;">
        ${data.username === appState.user ? `
          <button class="btn-secondary" style="width: 100%;">Modifier le profil</button>
          <button id="real-logout-btn" class="btn-secondary" style="width: 100%; margin-top: 8px; background: #fff; border: 1px solid var(--border-color);">Déconnexion</button>
        ` : `
          <button id="follow-btn" class="${isFollowing ? 'btn-secondary' : 'btn-primary'}" style="width: 100%; border-radius: 8px;">
            ${isFollowing ? 'Suivi' : 'Suivre'}
          </button>
        `}
      </div>

      <div style="border-top: 1px solid var(--border-color); display: flex; justify-content: space-around; padding: 12px 0;">
        <span style="font-weight: 600; font-size: 12px; text-transform: uppercase; border-top: 1px solid #000; padding-top: 10px; margin-top: -13px;">POSTS</span>
        <span style="font-weight: 500; font-size: 12px; text-transform: uppercase; color: var(--text-secondary);">REELS</span>
        <span style="font-weight: 500; font-size: 12px; text-transform: uppercase; color: var(--text-secondary);">IDENTIFIÉ</span>
      </div>

      <div class="profile-grid">
        ${data.posts.map(post => `
          <div class="grid-item" style="position: relative;">
            <div class="grid-overlay">❤️ ${post.likes}</div>
            ${post.type === 'video' ? `<video src="${post.url}" muted></video>` : `<img src="${post.url}">`}
            ${data.username === appState.user ? `
              <button class="delete-btn" data-id="${post.id}" style="position: absolute; top: 10px; right: 10px; z-index: 10; background: rgba(0,0,0,0.5); border: none; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 16px;">🗑️</button>
            ` : ''}
          </div>
        `).join('')}
      </div>
    </div>
  `;

  if (data.username === appState.user) {
    const container = document.getElementById('avatar-container');
    const overlay = document.getElementById('avatar-overlay');
    const input = document.getElementById('avatar-input');

    container.onmouseenter = () => overlay.style.opacity = '1';
    container.onmouseleave = () => overlay.style.opacity = '0';
    container.onclick = () => input.click();

    input.onchange = async (e) => {
      const file = e.target.files[0];
      if (!file) return;

      const formData = new FormData();
      formData.append('avatar', file);
      formData.append('username', appState.user);

      const res = await fetch('/api/profiles/avatar', {
        method: 'POST',
        body: formData
      });

      if (res.ok) {
        renderProfile(username);
      } else {
        alert('Erreur lors du changement de photo');
      }
    };
  }

  if (document.getElementById('follow-btn')) {
    document.getElementById('follow-btn').onclick = async () => {
      await fetch('/api/follows/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ follower: appState.user, following: username })
      });
      renderProfile(username);
    };
  }

  if (document.getElementById('real-logout-btn')) {
    document.getElementById('real-logout-btn').onclick = () => {
      localStorage.removeItem('user');
      appState.user = null;
      appState.view = 'login';
      checkSession();
      renderLogin();
    };
  }
}

async function checkNewNotifications() {
  if (!appState.user) return;
  const notifs = await fetchData(`notifications/${appState.user}`);
  const unread = notifs.filter(n => !n.read).length;
  const badge = document.getElementById('notif-badge');
  if (badge) {
    badge.style.display = unread > 0 ? 'block' : 'none';
  }
}

// Check notifications every 10 seconds
setInterval(checkNewNotifications, 10000);

async function renderNotifications() {
  const main = document.getElementById('main-content');
  main.innerHTML = '<div style="padding: 50px; text-align: center;">⌛</div>';
  const notifs = await fetchData(`notifications/${appState.user}`);

  // Mark as read (simple client-side logic for now)
  const badge = document.getElementById('notif-badge');
  if (badge) badge.style.display = 'none';

  main.innerHTML = `
    <div style="padding: 20px; background: #fafafa; min-height: calc(100vh - 120px);">
      <h2 style="margin-bottom: 25px; font-weight: 800; font-size: 28px;">Activités</h2>
      <div style="display: flex; flex-direction: column; gap: 12px;">
        ${notifs.length === 0 ? '<p style="text-align:center; color: var(--text-secondary); padding: 40px;">Vos notifications apparaîtront ici.</p>' : ''}
        ${(await Promise.all(notifs.map(async n => {
    const senderData = await fetchData(`profiles/${n.fromUser}`);
    const senderAvatar = senderData.avatar && senderData.avatar.startsWith('/uploads')
      ? `<img src="${senderData.avatar}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;">`
      : senderData.avatar || '👤';

    let actionText = '';
    let icon = '🔔';
    if (n.type === 'like') { actionText = 'a aimé votre publication.'; icon = '❤️'; }
    if (n.type === 'comment') { actionText = `a commenté: "${n.text}"`; icon = '💬'; }
    if (n.type === 'follow') { actionText = 'a commencé à vous suivre.'; icon = '👤'; }
    if (n.type === 'tag') { actionText = 'vous a identifié dans un post.'; icon = '🏷️'; }

    return `
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 16px; background: #000; color: #fff; border-radius: 16px; box-shadow: 0 4px 15px rgba(0,0,0,0.2); animation: slideIn 0.3s ease-out;">
              <div style="display: flex; align-items: center; gap: 15px; flex: 1;">
                <div style="position: relative;">
                  <div style="width: 48px; height: 48px; background: var(--insta-gradient); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px; border: 2px solid #333; overflow: hidden;">
                    ${senderAvatar}
                  </div>
                  <div style="position: absolute; bottom: -2px; right: -2px; background: #fff; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-size: 12px; border: 2px solid #000;">${icon}</div>
                </div>
                <div style="font-size: 14px; line-height: 1.4;">
                  <span style="font-weight: 700; cursor:pointer; color: #fff; text-decoration: underline;" onclick="renderProfile('${n.fromUser}')">${n.fromUser}</span> 
                  <span style="color: #ccc;">${actionText}</span>
                </div>
              </div>
              <div style="font-size: 11px; color: #666; font-weight: 500;">${formatTime(n.date)}</div>
            </div>
          `;
  }))).join('')}
      </div>
    </div>
  `;
}

function formatTime(dateStr) {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = Math.floor((now - date) / 1000);
  if (diff < 60) return 'à l\'instant';
  if (diff < 3600) return `${Math.floor(diff / 60)}m`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h`;
  return `${Math.floor(diff / 86400)}j`;
}

async function renderAddPost() {
  const main = document.getElementById('main-content');
  main.innerHTML = `
    <div class="auth-container" style="padding-top: 20px;">
      <h2 style="margin-bottom: 20px;">Nouveau Post</h2>
      
      <div id="upload-stage">
        <div style="display: flex; gap: 15px; margin-bottom: 20px;">
          <button class="btn-primary" onclick="document.getElementById('file-input').click()" style="margin: 0; flex: 1;">📁 Galerie</button>
          <button class="btn-primary" id="open-camera-btn" style="margin: 0; flex: 1; background: #000;">📷 Caméra</button>
        </div>
        <div style="border: 2px dashed var(--border-color); padding: 50px 20px; border-radius: var(--radius-md); background: #f9f9f9; text-align: center;">
          <input type="file" id="file-input" style="display: none;" accept="image/*,video/*">
          <p style="color: var(--text-secondary);">Choisissez une option ci-dessus</p>
        </div>
      </div>

      <div id="camera-stage" style="display: none; text-align: center;">
        <video id="camera-feed" autoplay playsinline style="width: 100%; border-radius: var(--radius-md); background: #000;"></video>
        <div style="display: flex; gap: 15px; margin-top: 20px;">
          <button class="btn-primary" id="capture-image-btn" style="margin: 0; flex: 1;">📸 Photo</button>
          <button class="btn-primary" id="capture-video-btn" style="margin: 0; flex: 1; background: #ff3040;">🎥 Vidéo (Hold)</button>
        </div>
        <button class="btn-secondary" onclick="renderAddPost()" style="margin-top: 15px; width: 100%;">Retour</button>
      </div>

      <div id="editor-stage" style="display: none;">
        <div id="preview-container" style="width: 100%; aspect-ratio: 1/1; background: #000; border-radius: var(--radius-md); overflow: hidden; margin-bottom: 20px;">
        </div>
        
        <div class="input-group">
          <input type="text" id="post-caption" placeholder="Écrivez une légende..." class="input-field">
          <input type="text" id="post-tags" placeholder="Identifier des amis (ex: @imrane)" class="input-field">
          
          <button class="btn-primary" id="final-publish-btn">Publier sur le Feed</button>
          <button class="btn-secondary" onclick="renderAddPost()">Recommencer</button>
        </div>
      </div>
    </div>
  `;

  const fileInput = document.getElementById('file-input');
  const cameraBtn = document.getElementById('open-camera-btn');
  const cameraStage = document.getElementById('camera-stage');
  const uploadStage = document.getElementById('upload-stage');
  const editorStage = document.getElementById('editor-stage');
  const cameraFeed = document.getElementById('camera-feed');
  const previewContainer = document.getElementById('preview-container');

  let stream = null;
  let mediaRecorder = null;
  let recordedChunks = [];
  let capturedFile = null;

  cameraBtn.onclick = async () => {
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      cameraFeed.srcObject = stream;
      uploadStage.style.display = 'none';
      cameraStage.style.display = 'block';
    } catch (err) {
      alert('Erreur caméra: ' + err.message);
    }
  };

  document.getElementById('capture-image-btn').onclick = () => {
    const canvas = document.createElement('canvas');
    canvas.width = cameraFeed.videoWidth;
    canvas.height = cameraFeed.videoHeight;
    canvas.getContext('2d').drawImage(cameraFeed, 0, 0);
    canvas.toBlob((blob) => {
      capturedFile = new File([blob], 'capture.png', { type: 'image/png' });
      showEditor(capturedFile);
    }, 'image/png');
    stopCamera();
  };

  const captureVideoBtn = document.getElementById('capture-video-btn');
  captureVideoBtn.onmousedown = () => {
    recordedChunks = [];
    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.ondataavailable = (e) => recordedChunks.push(e.data);
    mediaRecorder.onstop = () => {
      const blob = new Blob(recordedChunks, { type: 'video/mp4' });
      capturedFile = new File([blob], 'capture.mp4', { type: 'video/mp4' });
      showEditor(capturedFile);
      stopCamera();
    };
    mediaRecorder.start();
    captureVideoBtn.innerText = '🔴 Enregistrement...';
  };
  captureVideoBtn.onmouseup = () => {
    if (mediaRecorder) mediaRecorder.stop();
  };

  function stopCamera() {
    if (stream) stream.getTracks().forEach(t => t.stop());
  }

  function showEditor(file) {
    cameraStage.style.display = 'none';
    editorStage.style.display = 'block';
    previewContainer.innerHTML = '';

    if (file.type.startsWith('image/')) {
      const img = document.createElement('img');
      img.src = URL.createObjectURL(file);
      img.style.width = '100%';
      img.style.height = '100%';
      img.style.objectFit = 'cover';
      previewContainer.appendChild(img);
    } else {
      const video = document.createElement('video');
      video.src = URL.createObjectURL(file);
      video.controls = true;
      video.style.width = '100%';
      video.style.height = '100%';
      video.style.objectFit = 'contain';
      previewContainer.appendChild(video);
    }

    document.getElementById('final-publish-btn').onclick = async () => {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('user', appState.user);
      formData.append('caption', document.getElementById('post-caption').value);
      formData.append('type', file.type.startsWith('video/') ? 'video' : 'image');
      formData.append('tags', JSON.stringify(document.getElementById('post-tags').value.split(',').map(t => t.trim())));

      const res = await fetch('/api/posts', { method: 'POST', body: formData });
      if (res.ok) renderFeed();
    };
  }

  fileInput.onchange = (e) => {
    if (e.target.files[0]) showEditor(e.target.files[0]);
  };
}

async function renderLogin() {
  const main = document.getElementById('main-content');
  main.innerHTML = `
    <div class="auth-container">
      <h1 class="logo auth-logo">Instatock</h1>
      <div class="input-group">
        <input type="text" id="login-username" placeholder="Nom d'utilisateur" class="input-field">
        <input type="password" id="login-password" placeholder="Mot de passe" class="input-field">
        <button class="btn-primary" id="login-btn">Se connecter</button>
        <div style="margin-top: 20px; font-size: 14px;">
          Vous n'avez pas de compte ? <a href="#" id="go-to-signup" style="color: var(--accent-color); font-weight: 600; text-decoration: none;">Inscrivez-vous</a>
        </div>
      </div>
    </div>
  `;

  document.getElementById('login-btn').onclick = async () => {
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (res.ok) {
      localStorage.setItem('user', data.user);
      appState.user = data.user;
      checkSession();
      renderFeed();
    } else {
      alert(data.error);
    }
  };

  document.getElementById('go-to-signup').onclick = renderSignup;
}

async function renderSignup() {
  const main = document.getElementById('main-content');
  main.innerHTML = `
    <div class="auth-container">
      <h1 class="logo auth-logo">Instatock</h1>
      <p style="color: var(--text-secondary); margin-bottom: 20px;">Inscrivez-vous pour voir les moments de vos amis.</p>
      <div class="input-group">
        <input type="text" id="signup-username" placeholder="Nom d'utilisateur" class="input-field">
        <input type="password" id="signup-password" placeholder="Mot de passe" class="input-field">
        <button class="btn-primary" id="signup-btn">S'inscrire</button>
        <div style="margin-top: 20px; font-size: 14px;">
          Vous avez déjà un compte ? <a href="#" id="go-to-login" style="color: var(--accent-color); font-weight: 600; text-decoration: none;">Connectez-vous</a>
        </div>
      </div>
    </div>
  `;

  document.getElementById('signup-btn').onclick = async () => {
    const username = document.getElementById('signup-username').value;
    const password = document.getElementById('signup-password').value;
    const res = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (res.ok) {
      alert('Compte créé ! Veuillez vous connecter.');
      renderLogin();
    } else {
      alert(data.error);
    }
  };

  document.getElementById('go-to-login').onclick = renderLogin;
}

async function renderChannels(searchQuery = '') {
  const main = document.getElementById('main-content');
  let channels = await fetchData('channels');

  if (searchQuery) {
    channels = channels.filter(ch => ch.name.toLowerCase().includes(searchQuery.toLowerCase()));
  }

  main.innerHTML = `
    <div style="padding: 20px;">
      <h2 style="margin-bottom: 20px;">Chaînes recommandées</h2>
      
      <div style="display: flex; gap: 10px; margin-bottom: 15px;">
        <input type="text" id="search-channel-name" value="${searchQuery}" placeholder="Rechercher une chaîne..." class="input-field" style="margin: 0; flex: 1;">
        <button id="search-channel-btn" class="btn-primary" style="margin: 0; width: auto; padding: 0 20px;">🔍</button>
      </div>

      <div style="display: flex; gap: 10px; margin-bottom: 24px;">
        <input type="text" id="new-channel-name" placeholder="Nouveau nom..." class="input-field" style="margin: 0; flex: 1;">
        <button id="create-channel-btn" class="btn-primary" style="margin: 0; width: auto; padding: 0 20px;">Créer</button>
      </div>
      
      <div style="display: grid; grid-template-columns: 1fr; gap: 12px;">
        ${channels.length === 0 ? '<p style="text-align: center; color: var(--text-secondary); padding: 20px;">Aucune chaîne trouvée.</p>' : ''}
        ${channels.map(ch => `
          <div style="display: flex; align-items: center; justify-content: space-between; padding: 12px; border: 1px solid var(--border-color); border-radius: var(--radius-md);">
            <div style="display: flex; align-items: center; gap: 15px;">
              <div style="font-size: 24px; width: 50px; height: 50px; background: #f0f2f5; border-radius: 50%; display: flex; align-items: center; justify-content: center;">${ch.icon}</div>
              <div>
                <div style="font-weight: 600; font-size: 15px;">${ch.name}</div>
                <div style="font-size: 12px; color: var(--text-secondary);">${ch.members} abonnés</div>
              </div>
            </div>
            <button class="btn-secondary" style="padding: 8px 16px; font-size: 13px;">Rejoindre</button>
          </div>
        `).join('')}
      </div>
    </div>
  `;

  document.getElementById('search-channel-btn').onclick = () => {
    const query = document.getElementById('search-channel-name').value;
    renderChannels(query);
  };

  document.getElementById('search-channel-name').onkeyup = (e) => {
    if (e.key === 'Enter') {
      const query = document.getElementById('search-channel-name').value;
      renderChannels(query);
    }
  };

  document.getElementById('create-channel-btn').onclick = async () => {
    const name = document.getElementById('new-channel-name').value;
    if (!name) return;
    await fetch('/api/channels', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    });
    renderChannels();
  };
}

// Global Nav Handlers
document.querySelectorAll('.mobile-nav button, header button').forEach(btn => {
  btn.addEventListener('click', () => {
    // This is a generic handler, specific ones are below
  });
});

document.getElementById('home-btn').onclick = renderFeed;
document.getElementById('notifications-btn').onclick = renderNotifications;
document.getElementById('add-post-btn').onclick = renderAddPost;
document.getElementById('channels-btn').onclick = renderChannels;
document.getElementById('profile-btn').onclick = () => renderProfile();

// Initial Init
checkSession();
if (appState.view === 'login') {
  renderLogin();
} else {
  renderFeed();
}
